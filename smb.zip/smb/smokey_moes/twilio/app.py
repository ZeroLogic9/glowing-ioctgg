import twilio.rest
from twilio.rest import Client

from load_env import get_value_from_key


def setup() -> Client:
    return Client(get_value_from_key("ACCOUNT_SID"), get_value_from_key("AUTH_TOKEN"))


def send_sms(client, number, message):
    client.messages.create(
        to=number,
        from_='+18669841207',
        body=message)
