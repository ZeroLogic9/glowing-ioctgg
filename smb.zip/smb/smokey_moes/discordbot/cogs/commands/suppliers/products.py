import discord
from discord.ext import commands
from discord import app_commands

from smokey_moes.discordbot.bot import SmokeyMoeBot


class Products(commands.Cog):
    def __init__(self, bot: SmokeyMoeBot):
        self.bot = bot

    @app_commands.command(name="watchlist", description="List of all products being watched.")
    async def watchlist(self, interaction: discord.Interaction):
        if not interaction.permissions.administrator:
            await self.bot.respond_invalid_permissions(interaction)
            return
        for product in self.bot.watchlist:
            pass

    @app_commands.command(name="watch", description="Add a product to the bot's watch list.")
    async def watch(self, interaction: discord.Interaction):
        if not interaction.permissions.administrator:
            await self.bot.respond_invalid_permissions(interaction)
            return

    @app_commands.command(name="unwatch", description="Remove a product from the bot's watch list.")
    async def unwatch(self, interaction: discord.Interaction):
        if not interaction.permissions.administrator:
            await self.bot.respond_invalid_permissions(interaction)
            return


async def setup(bot: SmokeyMoeBot):
    await bot.add_cog(Products(bot))
