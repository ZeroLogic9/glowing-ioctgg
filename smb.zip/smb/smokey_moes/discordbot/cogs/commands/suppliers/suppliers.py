import discord
from discord.ext import commands
from discord import app_commands

from smokey_moes.discordbot.bot import SmokeyMoeBot


class Suppliers(commands.Cog):
    def __init__(self, bot: SmokeyMoeBot):
        self.bot = bot


async def setup(bot: SmokeyMoeBot):
    await bot.add_cog(Suppliers(bot))
