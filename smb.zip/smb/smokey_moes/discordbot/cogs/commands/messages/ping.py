import discord
from discord.ext import commands
from discord import app_commands

from smokey_moes.discordbot.bot import SmokeyMoeBot


class Ping(commands.Cog):
    def __init__(self, bot: SmokeyMoeBot):
        self.bot = bot

    @app_commands.command(name="ping", description="Ping the bot for network and debug statistics")
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Number of Ticks: {self.bot.num_of_ticks}")


async def setup(bot: SmokeyMoeBot):
    await bot.add_cog(Ping(bot))
