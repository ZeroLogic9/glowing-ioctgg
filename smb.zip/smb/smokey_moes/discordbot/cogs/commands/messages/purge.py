import discord
from discord.ext import commands
from discord import app_commands

from smokey_moes.discordbot.bot import SmokeyMoeBot


class Purge(commands.Cog):
    def __init__(self, bot: SmokeyMoeBot):
        self.bot = bot

    @app_commands.command(name="purge", description="Purge the channel where the command is residing in")
    async def purge(self, interaction: discord.Interaction, _range: int = 100):
        if interaction.permissions.administrator or interaction.permissions.manage_messages:
            await interaction.response.defer()
            await interaction.channel.purge(limit=_range)
            await self.bot.fast_send(interaction.channel, "Successful Purge",
                                     f"Purged the last {_range} messages "
                                     f"of {interaction.channel.mention} successfully.",
                                     self.bot.green_color)
            return

        await self.bot.respond_invalid_permissions(interaction)


async def setup(bot: SmokeyMoeBot):
    await bot.add_cog(Purge(bot))
