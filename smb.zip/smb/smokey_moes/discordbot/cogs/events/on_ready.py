import asyncio
import datetime
import json
import time

import discord
from discord.ext import commands

from smokey_moes.discordbot.bot import SmokeyMoeBot
from smokey_moes.twilio.app import send_sms

class OnReady(commands.Cog):
    def __init__(self, bot: SmokeyMoeBot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        await self.bot.change_presence(
            status=discord.Status.do_not_disturb,
            activity=discord.Activity(type=discord.ActivityType.watching, name="9 Smoke Shops")
        )

        await self.bot.read_locations()

        self.bot.start_time = datetime.datetime.now()
        self.bot.timer.start()
        print(f"{self.bot.start_time} | {self.bot.user.name}#{self.bot.user.discriminator} is now Active!")
        send_sms(self.bot.twilio_client, "+18102637195", "Discord Bot Activated")
        # send_sms(self.bot.twilio_client, "+18108282360", "Discord Bot Activated")


async def setup(bot: SmokeyMoeBot):
    await bot.add_cog(OnReady(bot))
