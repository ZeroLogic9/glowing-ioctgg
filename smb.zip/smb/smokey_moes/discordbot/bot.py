import datetime
import os
import json

import asyncio

import discord
import requests
from discord.ext import commands

import smokey_moes.twilio.app
from quick_embed import quick_embed
from timer import Timer

from smokey_moes.fastrax.ftx import login_fastrax, check_login
from smokey_moes.fastrax.loyalty.pos_message import check_pos_sales
from smokey_moes.fastrax.loyalty.loyalty_signup import check_loyalty_signups

class SmokeyMoeBot(commands.Bot):
    def __init__(self, token: str, prefix: str, env: dict = None):
        super().__init__(command_prefix=prefix, help_command=None, intents=discord.Intents.all())
        self._token = token
        self.base_directory = os.getcwd()

        self.env = env

        self.bot_directory = "smokey_moes\\discordbot"
        self.bot_path = self.base_directory + self.bot_directory

        self.cog_directory = self.bot_directory + "\\cogs"
        self.cog_path = self.base_directory + "\\" + self.cog_directory
        self.cog_module = self.cog_directory.replace("\\", ".")

        self.ftx_session: requests.Session | None = None

        self.twilio_client = smokey_moes.twilio.app.setup()

        self.locations = []

        self.products = []
        self.watchlist = []

        self.start_time = None
        self.sent_receipts = []

        self.green_color = 0x00FF00
        self.red_color = 0xFF0000

        self.num_of_ticks = 0

        self.timer = Timer(100, self.tick)

    """
    Each array within the 2D Array correspond to [func, args, interval (ms)] 
    Runs a async func every interval it is set at in milliseconds.
    """
    def get_tick_funcs(self):
        return [
            [self.ftx_check_login, [], 3000],
            [self.sync_ftx_products, [], 3000],
            [self.check_pos_sales, [], 50],
            [self.check_loyalty_signups, [], 50],
            [self.reset_receipts, [], 9000]
        ]

    '''
    Ticks the discord bot.
    100ms per tick.
    '''
    def tick(self):
        self.num_of_ticks += 1

        for func in self.get_tick_funcs():
            if self.num_of_ticks % func[2] == 0:
                asyncio.run(func[0](*func[1]))

    async def reset_ticks(self):
        self.num_of_ticks = 0

    async def reset_receipts(self):
        cur_time = datetime.datetime.now().time()
        if datetime.time(0, 0, 0) < cur_time < datetime.time(8, 0, 0):
            self.sent_receipts = []
            await self.read_locations()
            self.start_time = cur_time

    async def check_pos_sales(self):
        self.sent_receipts += await check_pos_sales(self.ftx_session, self.twilio_client, self.start_time, self.sent_receipts, self.locations)

    async def check_loyalty_signups(self):
        check_loyalty_signups(self.ftx_session)

    async def ftx_check_login(self):
        if not await check_login(self.ftx_session):
            self.ftx_session = await login_fastrax(self.env["FTX_USER"], self.env["FTX_PASSWORD"])

    async def sync_ftx_products(self):
        print("Fake Synced, Fastrax")

    async def read_locations(self):
        with open("locations.json", 'r') as locations_file:
            self.locations = json.load(locations_file)
            locations_file.close()
        return self.locations

    async def fast_send(self, channel: discord.TextChannel, title, body, color):
        await channel.send(
            embed=quick_embed(title=title, fields=[[body, "", False]], color=color, icon=self.user.display_avatar.url))

    async def fast_respond(self, interaction: discord.Interaction, title, body, color, ephemeral=False):
        return await interaction.response.send_message(
            embed=quick_embed(title=title, fields=[[body, "", False]], color=color, icon=self.user.display_avatar.url),
            ephemeral=ephemeral)

    async def respond_invalid_permissions(self, interaction: discord.Interaction):
        await self.fast_respond(interaction, "Invalid Permissions", f"This command requires higher permissions to use.",
                                self.red_color)

    async def sync_app_commands(self):
        print(f"{len(await self.tree.sync())} commands synced globally")

    async def reset_watchlist(self):
        self.watchlist = []
        for product in self.products:
            if product["watch"]:
                self.watchlist.append(product)
        return self.watchlist

    async def setup_hook(self) -> None:
        for cog in self.parse_cogs(self.cog_path, self.cog_module):
            await self.load_extension(cog)
            print("Loaded: " + cog)
        await self.sync_app_commands()

        self.ftx_session = await login_fastrax(self.env["FTX_USER"], self.env["FTX_PASSWORD"])

        with open(f"{self.base_directory}\\smokey_moes\\products.json", "r") as productfile:
            self.products = json.load(productfile)
            productfile.close()
        await self.reset_watchlist()

    @classmethod
    def parse_cogs(cls, cog_path, cog_module) -> list:
        cogs = []
        for item in os.listdir(cog_path):
            if os.path.isdir(cog_path + "\\" + item):
                cogs += cls.parse_cogs(cog_path + "\\" + item, cog_module + "." + item)
                continue
            if item.endswith(".py"):
                cogs.append(cog_module + "." + item[:-3])
        return cogs

    @classmethod
    def run(cls, token: str, prefix: str, env: dict = None) -> None:  # noqa
        SmokeyMoeBot(token, prefix, env).self_run()

    def self_run(self):
        super().run(self._token)
