'''
POST https://cc.fastraxpos.com/client/loyalty/customers/store

'''

import base64
import json
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import pandas
import io
import random

from load_env import get_value_from_key


def cap_words(string):
    x = string.lower().split()
    y = []
    for word in x:
        y.append(word.capitalize())
    return " ".join(y)


POLICIES = """I consent to terms & condition, refund policy, privacy policy.

I accept to recieve promotional offers and news via email and SMS."""

SPREADSHEET_URL = "https://docs.google.com/spreadsheets/d/13V44deuSqpLeQNzhtp6D5ApASLBUMGPyZolUYBYo6ag/edit#gid=0"

SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]

secret = base64.b64decode(get_value_from_key("GOOGLE_SECRET")).decode("utf-8")
CREDENTIALS = ServiceAccountCredentials.from_json_keyfile_dict(json.loads(secret), scopes=SCOPES)

file = gspread.authorize(CREDENTIALS)


def get_sheet():
    spreadsheet = file.open_by_url(SPREADSHEET_URL)
    out_sheet = spreadsheet.sheet1
    out_data = pandas.read_csv(io.StringIO(spreadsheet.export(gspread.utils.ExportFormat.CSV).decode())).to_json(
        orient="records")
    return out_sheet, json.loads(out_data)


def add_customer(login_session, first, last, phone, email, address, city, state, zip) -> bool:
    resp = login_session.post("https://cc.fastraxpos.com/client/loyalty/customers/store", files=(
        ("account_id", (None, "426")),
        ("first_name", (None, first)),
        ("last_name", (None, last)),
        ("username", (None, f"{first}.{last}.{random.randint(1, 999)}")),
        ("email", (None, email)),
        ("customer_description", (None, POLICIES)),
        ("customer_sex", (None, "Male")),
        ("customer_type", (None, "0")),
        ("phone", (None, str(phone))),
        ("city", (None, city)),
        ("state", (None, "MI")),
        ("zip", (None, zip)),
        ("address_line_1", (None, address)),
        ("lajx", (None, "true")),
        ("_token", (None, login_session.headers.get("X-Csrf-Token")))
    ))
    if resp.json()["msgType"] == "success":
        print(f"Added {first} {last} to Fastrax.")


def check_loyalty_signups(session):
    try:
        sheet, data = get_sheet()
    except gspread.exceptions.APIError:
        return

    for person in data:
        add_customer(session, cap_words(str(person["First Name"])), cap_words(str(person["Last Name"])),
                     str(person["Phone"]), str(person["Email"]), cap_words(str(person["Address"])),
                     cap_words(str(person["City"])), cap_words(str(person["State"])), str(person["Zip Code"]))
        try:
            sheet.delete_row(sheet.find(str(person["Phone"])).row)
        except AttributeError:
            continue
