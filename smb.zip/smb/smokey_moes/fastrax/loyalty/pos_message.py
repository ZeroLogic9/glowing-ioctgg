import datetime

import bs4
from bs4 import BeautifulSoup

from smokey_moes.fastrax.ftx import check_login

from smokey_moes.twilio.app import send_sms


async def check_pos_sales(ftx_session, client, start_time, receipts, locations):
    if not await check_login(ftx_session):
        return

    strftime = start_time.strftime('%m/%d/%Y')
    current = datetime.datetime.now().strftime('%m/%d/%Y')

    r = ftx_session.get(
        f"https://cc.fastraxpos.com/client/loyalty/receipts?lajx=true&rangeStart={strftime}&rangeEnd={current}&filter[text][sale_total]=&sorting=&searchId=&perPage=1000&filter[text][email]=&filter[text][first_name]=&filter[text][last_name]=&filter[model][location_id]=&filter[data][employee_account]=&filter[text][receipt_number]=")

    soup = BeautifulSoup(r.json()["html"], features="html.parser")
    sent_receipts = []

    for loyalty_sale_html in soup.find(class_="list-scroll").children:
        sale_html: bs4.PageElement = [c for c in loyalty_sale_html.children][1]
        purchase_time_str = sale_html.find(class_="date-time-date").text
        purchase_time = datetime.datetime.strptime(purchase_time_str, '%m/%d/%Y %I:%M %p')
        strp_start = datetime.datetime.strptime(start_time.strftime("%m/%d/%Y %I:%M %p"), "%m/%d/%Y %I:%M %p")
        receipt = hash(
            (sale_html.find(attrs={"data-head": "Receipt #"}).text, sale_html.find(class_="emp-location").text))

        if purchase_time >= strp_start and receipt not in receipts:
            print(receipt, receipts)
            btns_html: bs4.PageElement = [c for c in loyalty_sale_html.children][2]
            names = [n for n in sale_html.find(class_="name").children]
            name, last = names[0].text, names[1].text
            link = [lnk for lnk in btns_html.find(class_="model-table-btns").children][0]["href"]

            receipt_soup = BeautifulSoup(ftx_session.get(link + "?lajx=true").json()["html"], features="html.parser")
            number = receipt_soup.find_all("tbody")[1].find_all("tr")[2].find_all("td")[1].text

            id_soup = BeautifulSoup(ftx_session.get("https://cc.fastraxpos.com/client/loyalty/customer-balance?"
                                                    f"filter[text][first_name]={name}&filter[text][last_name]={last}"
                                                    '&sorting={"dataKey":"updated_at",'
                                                    '"direction":"desc"}'
                                                    + "&lajx=true").json()["html"], features="html.parser")

            points = 0
            total_points = 0
            bal_hist = id_soup.find_all(class_="content-row-wrap")
            if len(bal_hist) > 0:
                try:
                    bcid = bal_hist[0].find_all("a")[-1]["data-customer-balance-id"]
                    no_points = False
                except KeyError:
                    total_points = float(bal_hist[0].find("div", {"data-head": "Balance"}).text.replace(",", ""))
                    no_points = True
                if not no_points:
                    points_history = ftx_session.get("https://cc.fastraxpos.com/ajax/get-balance-history?"
                                                     f"offset=0&perPage=50&draw=1&customer_balance_id={bcid}&accountType=1"
                                                     "&campaign_id=").json()["data"]

                    total_points = float(points_history[0]["balance_after"])

                    for points_added in points_history:
                        if datetime.datetime.strptime(points_added["timestamp"], '%m/%d/%Y %I:%M %p') < purchase_time:
                            break
                        points += float(points_added["balance_added"])

            points_msg = ""
            if points > 0:
                points_msg = f"Great news! You've earned {points} points, bringing your total balance to {total_points} points. Keep up the great work!"

            msg = f"""{points_msg}\n\nThank you for shopping at Smokey Moe's Tobacco! We hope you had a great experience and would love to hear your feedback. Your input helps us improve and continue providing the best service possible. Please take a moment to share your thoughts with us."""

            location = sale_html.find(class_="emp-location").find_next("a").text

            send_sms(client, "+1" + number.replace("-", ""), msg)
            send_sms(client, "+1" + number.replace("-", ""), locations[location])
            sent_receipts.append(receipt)

        return sent_receipts
