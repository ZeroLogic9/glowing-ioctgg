import requests
from bs4 import BeautifulSoup


async def login_fastrax(usr, pswd):
    loginSession = requests.Session()
    soup = BeautifulSoup(loginSession.get("https://cc.fastraxpos.com/").text, features='html.parser')
    token = soup.find("input").attrs["value"]
    if len(loginSession.post("https://cc.fastraxpos.com/login", headers={
        "Content-Type": 'application/x-www-form-urlencoded'
    },
                             data=f"_token={token}&email={usr}&password={pswd}&remember=on").text) < 50000:
        print(f"Failed to Login (Fastrax)\n")
        return None

    loginSession.headers.setdefault("X-Csrf-Token", token)
    loginSession.headers.setdefault("X-Requested-With", "XMLHttpRequest")

    return loginSession


async def check_login(ftxSession: requests.Session) -> bool:
    if ftxSession.get("https://cc.fastraxpos.com/client/dashboard", allow_redirects=False).status_code != 200:
        return False
    return True
