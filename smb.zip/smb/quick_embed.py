import discord


def quick_embed(*, title: str = "", value: str = "", color=0x00FF00, icon=None, url=None,
                fields=None, thumbnail=None) -> discord.Embed:
    if fields is None:
        fields = []
    embed = discord.Embed(color=color).set_author(name=title, url=url, icon_url=icon).add_field(name="", value=value)
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)
    for field in fields:
        embed.add_field(name=field[0], value=field[1], inline=False)
    return embed
