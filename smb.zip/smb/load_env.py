def get_value_from_key(key: str):
    with open(".env", "r") as env:
        for line in env.read().split("\n"):
            if not line or "#" == line[0]:
                continue
            k, v = line.split("=")
            if key == k:
                env.close()
                return v
    raise KeyError(f"Key: '{key}', not found")


def load_env():
    _env = {}
    with open(".env", "r") as env:
        for line in env.read().split("\n"):
            if not line or "#" == line[0]:
                continue
            k, v = line.split("=")
            _env = {**_env, **{k: v}}
        env.close()
        return _env
