import threading
import time


class Timer:
    def __init__(self, interval_milliseconds: int, target):
        self.interval_milliseconds = interval_milliseconds
        self.target = target
        self.kill_thread = False
        self.thread = None

    def stop(self):
        self.kill_thread = True

    def action(self):
        while True:
            time.sleep(self.interval_milliseconds/1000)
            if self.kill_thread:
                break
            self.target()

    def start(self):
        self.kill_thread = False
        self.thread = threading.Thread(target=self.action)
        self.thread.start()
