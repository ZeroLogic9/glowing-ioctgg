import load_env

print(load_env.load_env())