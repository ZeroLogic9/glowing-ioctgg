from smokey_moes.discordbot.bot import SmokeyMoeBot
from load_env import load_env

env = load_env()

SmokeyMoeBot.run(env["TOKEN"], env["PREFIX"], env=env)
